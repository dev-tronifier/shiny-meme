import os
from discord.ext.commands import Bot
from discord.ext import tasks
from discord import Member
import discord
import datetime
import logging
import platform
from colorama import init
from termcolor import colored
import time
from datetime import timedelta
import matplotlib.pyplot as plt
import requests
from io import BytesIO
from PIL import Image
import glob
from matplotlib.offsetbox import OffsetImage,AnnotationBbox
import numpy as np
import re
machine = platform.node()
init()
logging.basicConfig(format="%(asctime)s %(message)s", level=logging.INFO)

class Logger:
    def __init__(self, app):
        self.app = app

    def info(self, message):
        print(colored(
            f'[{time.asctime(time.localtime())}] [{machine}] [{self.app}] {message}', 'yellow'))

    def success(self, message):
        print(colored(
            f'[{time.asctime(time.localtime())}] [{machine}] [{self.app}] {message}', 'green'))

    def error(self, message):
        print(colored(
            f'[{time.asctime(time.localtime())}] [{machine}] [{self.app}] {message}', 'red'))

    def color(self, message, color):
        print(colored(
            f'[{time.asctime(time.localtime())}] [{machine}] [{self.app}] {message}', color))

logger = Logger("kourage-presence")

intents = discord.Intents.all()
intents.members = True
bot = Bot(command_prefix='~', intents=intents)
data = {}   # creating a dict to stpre info in the following format {user:{total_time:'',start_time:''}}


@bot.event
async def on_ready():
    logger.info("We have logged in as {0.user}".format(bot))
    load_dictionary_koders.start()  # starts the task event
    logger.success("~Kourage bot is running at 0.1.0")

koders_members = []
avatars = []

def gif2frame(gif):
    imageObject = Image.open(gif)
    imageObject.seek(0)
    imageObject.save("temp_frame.png")
    frame = Image.open('temp_frame.png')
    return frame

@tasks.loop(minutes=1)
async def load_dictionary_koders():
    global koders_members
    global avatars
    channel = await bot.fetch_channel(868036722326388736)   #855113118221205526
    guild = channel.guild
    logger.info('~load_dictionary_koders called for guild ' + str(guild.id) +
                '/' + guild.name + " : " + str(channel.id) + "/" + channel.name)
    global data
    # graph plotting from previous days data
    if len(data) != 0:
        ids = list(data.keys())
        totaltime = []
        for member in koders_members:
            # data[member.name]['total_time'] += ((datetime.datetime.now()) - data[member.name]['start_time'])
            if member.status == discord.Status.online:
                print(member.name)
                mem_time = (datetime.datetime.now() -
                            data[member.name]['start_time'])
                del data[member.name]
                data[member.name] = {'total_time': datetime.timedelta(
                    0), 'start_time': datetime.timedelta(0)}
                data[member.name]['total_time'] += mem_time
                data[member.name]['start_time'] = datetime.timedelta(0)
        for x in ids:
            if type(data[x]['total_time']) == datetime.datetime:
                totaltime.append(int(data[x]['total_time'].second))
            else:
                totaltime.append(int(data[x]['total_time'].total_seconds()))
        print(ids)
        print(type(ids))
        height = 0.8
        plt.barh(y=ids, width=totaltime, height=0.8, align='center')
        print(avatars)
        for i, (rp,value) in enumerate(zip(avatars,totaltime)):
            response = requests.get(rp)
            if requests.head(rp).headers['Content-Type'] != 'image/png':
                frame = gif2frame(BytesIO(response.content))
                plt.imshow(frame,extent=[value - 5, value - 2, i - height / 2, i + height / 2], aspect='auto', zorder=2)
            else:
                img = plt.imread(BytesIO(response.content))
                plt.imshow(img,extent=[value - 5, value - 2, i - height / 2, i + height / 2], aspect='auto', zorder=2)
        plt.xlim(0, max(totaltime) * 1.05)
        plt.ylim(-0.5, len(ids) - 0.5)
        plt.xlabel('Total online time')
        plt.ylabel('Names')
        plt.title('Online status')
        plt.tight_layout()
        plt.savefig('temp.png')
        plt.clf()
        await channel.send(file=discord.File('temp.png'), delete_after = 43200)

    data = {}
    koders_members = []
    avatars = []
    for member in guild.members:
        for role in member.roles:
            if role.name == "Koders":
                print(member.avatar_url)
                avatars.append(member.avatar_url)
                koders_members.append(member)
                if member.status == discord.Status.online:  # to check user status when the task runs
                    data[member.name] = {"total_time": datetime.timedelta(
                            0), 'start_time': datetime.datetime.now()}
                else:
                    data[member.name] = {'total_time': datetime.timedelta(
                            0), 'start_time': datetime.timedelta(0)}
    print(data)
    logger.success("'~load_dictionary_koders' executed successfully.")


@bot.event
async def on_member_update(usr_before, usr_after):
    global data
    logger.info('Before status: ' + usr_before.name +
                '/' + str(usr_before.status))
    logger.info('After status: ' + usr_after.name +
                '/' + str(usr_after.status))
    try:
        if(data[usr_before.name]['start_time'] == datetime.timedelta(0)):
            data[usr_before.name]['start_time'] = datetime.datetime.now()
        else:
            data[usr_before.name]['total_time'] += (
                datetime.datetime.now()-data[usr_before.name]['start_time'])
            data[usr_before.name]['start_time'] = datetime.timedelta(0)
    except Exception as err:
        pass
    logger.success("'~on_member_update' executed successfully.")

if __name__ == '__main__':
    try:
        bot.run(os.environ.get('TOKEN'))
    except Exception as err:
        logger.error("Exception found at main worker.\n", str(err))
